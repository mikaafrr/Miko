// Function to fetch data from Flask API and update the page
function fetchData() {
    fetch("/data") // Fetch data from Flask endpoint
        .then(response => response.json())
        .then(data => {
            console.log("Fetched data:", data); // Log data for debugging
            // Loop through each key and update the corresponding element
            Object.keys(data).forEach((key) => {
                let elementId = `opc-data-${key}`;
                document.getElementById(elementId).innerText = data[key] !== null ? data[key] : "No data available";
            });
        })
        .catch(err => {
            console.error("Error fetching data:", err);
        });
}

// Automatically fetch data every second
setInterval(fetchData, 1000);
