function fetchRealTimeData() {
    fetch('/get_current_process_data')
        .then(response => response.json())
        .then(data => {
            console.log(data); // Log data to inspect

            // Assuming Ideal Cycle Time and Auto Time are coming from the data
            const idealCycleTime = 10; // Ideal production time set to 10000 seconds
            const plannedProductionTime = 10000; // Ideal production time set to 10000 seconds

            // Calculate Performance
            const performance = (idealCycleTime * data.TotalWpKicked) / data.AutoCount;
            const performancePercentage = (performance * 100).toFixed(2); // Convert to percentage with 2 decimals

            // Calculate Availability
            const availability = (data.AutoCount / plannedProductionTime) * 100; // Based on 10,000 seconds ideal production time
            const availabilityPercentage = availability.toFixed(2); // Convert to percentage with 2 decimals

            // Calculate Quality
            const quality = (data.GoodCount / data.BadQualityCount) * 100;
            const qualityPercentage = quality.toFixed(2);

            const oee = (quality * performance * availability) / 100
            const oeePercentage = oee.toFixed(2); // Convert to percentage with 2 decimals

            // Update the HTML elements with the calculated percentages
            document.getElementById('performancePercentage').textContent = `${performancePercentage}%`;
            document.getElementById('availabilityPercentage').textContent = `${availabilityPercentage}%`;
            document.getElementById('qualityPercentage').textContent = `${qualityPercentage}%`;
            document.getElementById('oeePercentage').textContent = `${oeePercentage}%`;

        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
}

setInterval(fetchRealTimeData, 1000); // Update every second
