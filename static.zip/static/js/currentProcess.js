function fetchRealTimeData() {
    fetch('/get_current_process_data')
        .then(response => response.json())
        .then(data => {
            console.log(data); // Log data to inspect

            // Check if each element exists before updating
            const autoCountElement = document.getElementById('autoCountValue');
            if (autoCountElement) autoCountElement.textContent = data.AutoCount;

            const stopCountElement = document.getElementById('stopCountValue');
            if (stopCountElement) stopCountElement.textContent = data.StopCount;

            const currentModeElement = document.getElementById('currentModeValue');
            if (currentModeElement) currentModeElement.textContent = data.CurrentMode;

            const badQualityCountElement = document.getElementById('badQualityCountValue');
            if (badQualityCountElement) badQualityCountElement.textContent = data.BadQualityCount;

            const conveyorForwardElement = document.getElementById('conveyorForwardValue');
            if (conveyorForwardElement) conveyorForwardElement.textContent = data.ConveyorForward;

            const conveyorStartElement = document.getElementById('conveyorStartValue');
            if (conveyorStartElement) conveyorStartElement.textContent = data.ConveyorStart;

            const currentCycleElement = document.getElementById('currentCycleValue');
            if (currentCycleElement) currentCycleElement.textContent = data.CurrentCycle;

            const previousCycleElement = document.getElementById('previousCycleValue');
            if (previousCycleElement) previousCycleElement.textContent = data.PreviousCycle;

            const qualityElement = document.getElementById('qualityValue');
            if (qualityElement) qualityElement.textContent = data.Quality;

            const goodCountElement = document.getElementById('goodCountValue');
            if (goodCountElement) goodCountElement.textContent = data.GoodCount;

            const totalQualityCountElement = document.getElementById('totalQualityCountValue');
            if (totalQualityCountElement) totalQualityCountElement.textContent = data.TotalQualityCount;

            const totalWpKickedElement = document.getElementById('totalWpKickedValue');
            if (totalWpKickedElement) totalWpKickedElement.textContent = data.TotalWpKicked;
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
}

setInterval(fetchRealTimeData, 100);