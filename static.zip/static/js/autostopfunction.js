// Function to send the value (true or false)
function sendValue(value) {
    fetch('/autoStopButton', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ value: value }),
    })
    .then(response => response.json())
    .then(data => {
        // Handle server response
        if (data.message) {
            document.getElementById('responseMessage').innerText = data.message;
        } else if (data.error) {
            document.getElementById('responseMessage').innerText = data.error;
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

// Function to create a ripple effect
function createRipple(event) {
    const button = event.currentTarget;
    const ripple = document.createElement("span");
    
    // Get button dimensions and position
    const rect = button.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;

    // Set up ripple properties
    ripple.style.width = ripple.style.height = `${size}px`;
    ripple.style.left = `${x}px`;
    ripple.style.top = `${y}px`;
    
    // Add ripple class for animation
    ripple.classList.add("ripple");
    
    // Append the ripple to the button
    button.appendChild(ripple);

    // Remove the ripple after animation ends
    ripple.addEventListener("animationend", () => {
        ripple.remove();
    });
}

// Event listeners for the buttons
document.getElementById('autoButton').addEventListener('click', function (event) {
    createRipple(event);  // Create ripple effect
    sendValue(true);  // Send `true` when Auto button is clicked
});

document.getElementById('stopButton').addEventListener('click', function (event) {
    createRipple(event);  // Create ripple effect
    sendValue(false);  // Send `false` when Stop button is clicked
});
